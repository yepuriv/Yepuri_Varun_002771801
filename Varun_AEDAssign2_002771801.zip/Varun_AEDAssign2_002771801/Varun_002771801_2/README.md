Varun_Kumar_002771801_AED_Assignment1


This Java Swing application is a hospital management system.

There are two packages

Model
UI
There are 5 admins: System Admin Doctor Admin Patient Admin Community Admin Hospital Admin

system username = system and
password = password

System Admin UI Username: Password: The system admin can can login using the respective username and password. The system admin can create a hospital admin by giving the details of name, username and passwords for a hospital. The system admin can create community admin by giving the details of name, username and passwords for a community. The system admin can create vital signs by specifying the patient user name, body temperature, blood pressure, body pulse rate and date when the vital signs were noted down. The system admin can add patients by specifying the patient personal details. The system admin can create doctors by entering the name, username and password.

Patient Admin UI Patient can login with the respective username and password or else create a new account. For creating a new account, the patient must enter the personal details and also the username and password. After logging in, the patient can view the encounter history, can look for hospitals and doctors, edit the personal details. After login, the patient can book an appointment by selecting a city, community, hospital and doctor.

Doctor Admin UI Doctor can login with the respective username and password. The doctor can create vitals The doctor can manage the vital signs of the patients in the encounter history.

Community Admin UI The community admin can login and add cities, hospitals and communities.

Hospital Admin UI The hospital admin can can login using the respective username and password. After logging in, the hospital admin can add a doctor by giving the details of the city, community, hospital and doctor.

